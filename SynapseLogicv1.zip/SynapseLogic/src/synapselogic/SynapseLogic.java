package synapselogic;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class SynapseLogic {

    public static void main(String[] args) {

        System.out.println("=======================================");
        System.out.println(" PRUEBA GENERAL SYNAPSELOGIC");
        System.out.println("=======================================\n");

        try {
            File archivoNeuro = crearArchivoNeurotransmisores();
            File archivoRed = crearArchivoRed();

            TablaHash<String, Neurotransmisor> diccionario = probarCargadorNeurotransmisores(archivoNeuro);
            GrafoDirigidoListaAdyacencia grafo = probarCargadorRed(archivoRed);

            probarConectividadSobreGrafoCargado(grafo);
            probarCalculoPesoW(grafo, diccionario);
            probarDeterioro(grafo, diccionario);
            probarEliminacionDespuesDeCarga(grafo);

            System.out.println("\n=======================================");
            System.out.println(" TODAS LAS PRUEBAS GENERALES PASARON");
            System.out.println("=======================================");

        } catch (Exception e) {
            System.out.println("\n=======================================");
            System.out.println(" PRUEBA FALLIDA");
            System.out.println("=======================================");
            e.printStackTrace();
        }
    }

    private static TablaHash<String, Neurotransmisor> probarCargadorNeurotransmisores(File archivoNeuro) {

        System.out.println("1) Probando CargadorNeurotransmisoresCSV y TablaHash...");

        CargadorNeurotransmisoresCSV cargador = new CargadorNeurotransmisoresCSV();
        TablaHash<String, Neurotransmisor> diccionario = cargador.cargar(archivoNeuro.getAbsolutePath());

        validar(diccionario != null, "El diccionario no debe ser null.");
        validar(diccionario.tamano() == 4, "El diccionario debe tener 4 neurotransmisores validos.");

        Neurotransmisor glu = diccionario.buscar("GLU");
        Neurotransmisor gaba = diccionario.buscar("GABA");
        Neurotransmisor ach = diccionario.buscar("ACH");
        Neurotransmisor da = diccionario.buscar("DA");

        validar(glu != null, "Debe existir GLU.");
        validar(gaba != null, "Debe existir GABA.");
        validar(ach != null, "Debe existir ACH.");
        validar(da != null, "Debe existir DA.");

        validarCasiIgual(glu.getVelocidad(), 2.5, "La velocidad de GLU debe ser 2.5.");
        validarCasiIgual(gaba.getVelocidad(), 1.2, "La velocidad de GABA debe ser 1.2.");
        validarCasiIgual(ach.getVelocidad(), 2.0, "La velocidad de ACH debe ser 2.0.");
        validarCasiIgual(da.getVelocidad(), 1.5, "La velocidad de DA debe ser 1.5.");

        System.out.println("   GLU: " + glu);
        System.out.println("   GABA: " + gaba);
        System.out.println("   OK: diccionario cargado correctamente.\n");

        return diccionario;
    }

    private static GrafoDirigidoListaAdyacencia probarCargadorRed(File archivoRed) {

        System.out.println("2) Probando CargadorRedCSV y grafo dirigido...");

        CargadorRedCSV cargador = new CargadorRedCSV();
        GrafoDirigidoListaAdyacencia grafo = cargador.cargar(archivoRed.getAbsolutePath());

        validar(grafo != null, "El grafo no debe ser null.");

        validar(grafo.getContadorNeuronas() == 6,
                "El grafo cargado debe tener 6 neuronas.");

        validar(grafo.getContadorSinapsis() == 7,
                "El grafo cargado debe tener 7 sinapsis validas. Las duplicadas o invalidas no deben contar.");

        validar(grafo.existeNeurona("1"), "Debe existir la neurona 1.");
        validar(grafo.existeNeurona("6"), "Debe existir la neurona 6.");

        validar(grafo.existeSinapsis("1", "2"),
                "Debe existir la sinapsis dirigida 1 -> 2.");

        validar(grafo.existeSinapsis("2", "6"),
                "Debe existir la sinapsis dirigida 2 -> 6.");

        validar(!grafo.existeSinapsis("2", "1"),
                "NO debe existir 2 -> 1 porque el grafo es dirigido.");

        validar(!grafo.existeSinapsis("6", "5"),
                "NO debe existir 6 -> 5 porque el grafo es dirigido.");

        System.out.println("   Neuronas cargadas: " + grafo.getContadorNeuronas());
        System.out.println("   Sinapsis cargadas: " + grafo.getContadorSinapsis());
        System.out.println("   OK: red cargada correctamente desde CSV.\n");

        return grafo;
    }

    private static void probarConectividadSobreGrafoCargado(GrafoDirigidoListaAdyacencia grafo) {

        System.out.println("3) Probando BFS, DFS y fuerte conexidad sobre grafo cargado...");

        AnalizadorConectividad analizador = new AnalizadorConectividad();

        ResultadoConectividad bfsDesde1 = analizador.analizarBFS(grafo, "1");

        validar(bfsDesde1.getAlcanzables().tamano() == 6,
                "BFS desde 1 debe alcanzar las 6 neuronas.");

        validar(bfsDesde1.getInalcanzables().estaVacia(),
                "BFS desde 1 no debe tener neuronas inalcanzables.");

        validar(!bfsDesde1.esFuertementeConexa(),
                "El grafo maestro NO debe ser fuertemente conexo.");

        ResultadoConectividad dfsDesde1 = analizador.analizarDFS(grafo, "1");

        validar(dfsDesde1.getAlcanzables().tamano() == 6,
                "DFS desde 1 debe alcanzar las 6 neuronas.");

        validar(dfsDesde1.getInalcanzables().estaVacia(),
                "DFS desde 1 no debe tener neuronas inalcanzables.");

        ResultadoConectividad bfsDesde6 = analizador.analizarBFS(grafo, "6");

        validar(bfsDesde6.getAlcanzables().tamano() == 1,
                "BFS desde 6 solo debe alcanzar la neurona 6.");

        validar(bfsDesde6.getInalcanzables().tamano() == 5,
                "BFS desde 6 debe tener 5 neuronas inalcanzables.");

        validar(!analizador.esFuertementeConexa(grafo),
                "esFuertementeConexa debe devolver false para el grafo maestro.");

        System.out.println("   Resultado BFS desde 1:");
        imprimirResultadoConectividad(bfsDesde1);

        System.out.println("   Resultado DFS desde 1:");
        imprimirResultadoConectividad(dfsDesde1);

        System.out.println("   Resultado BFS desde 6:");
        imprimirResultadoConectividad(bfsDesde6);

        System.out.println("   OK: conectividad correcta.\n");
    }

    private static void probarCalculoPesoW(
            GrafoDirigidoListaAdyacencia grafo,
            TablaHash<String, Neurotransmisor> diccionario) {

        System.out.println("4) Probando calculo de peso W con diccionario...");

        Sinapsis s = buscarSinapsis(grafo, "1", "2");

        validar(s != null, "Debe existir la sinapsis 1 -> 2.");

        Neurotransmisor nt = diccionario.buscar(s.getNeurotransmisor());

        validar(nt != null, "Debe existir el neurotransmisor de la sinapsis 1 -> 2.");

        double w = s.calcularW(nt.getVelocidad());

        double esperado = 0.85 / (2.5 * 1.0);

        validarCasiIgual(w, esperado,
                "El peso W de 1 -> 2 debe ser distancia / (velocidad * k).");

        System.out.println("   Sinapsis: " + s);
        System.out.println("   Neurotransmisor: " + nt.getId());
        System.out.println("   Velocidad: " + nt.getVelocidad());
        System.out.println("   W calculado: " + w);
        System.out.println("   OK: calculo de W correcto.\n");
    }

    private static void probarDeterioro(
            GrafoDirigidoListaAdyacencia grafo,
            TablaHash<String, Neurotransmisor> diccionario) {

        System.out.println("5) Probando SimuladorDeterioro...");

        Sinapsis s = buscarSinapsis(grafo, "1", "2");

        validar(s != null, "Debe existir la sinapsis 1 -> 2 antes del deterioro.");

        Neurotransmisor nt = diccionario.buscar(s.getNeurotransmisor());

        double kAntes = s.getK();
        double wAntes = s.calcularW(nt.getVelocidad());

        SimuladorDeterioro simulador = new SimuladorDeterioro(grafo);
        simulador.ejecutarCicloFatiga();

        double kDespues = s.getK();
        double wDespues = s.calcularW(nt.getVelocidad());

        validarCasiIgual(kDespues, kAntes * 1.2,
                "El deterioro debe multiplicar k por 1.2.");

        System.out.println("   k antes: " + kAntes);
        System.out.println("   k despues: " + kDespues);
        System.out.println("   W antes: " + wAntes);
        System.out.println("   W despues: " + wDespues);
        System.out.println("   OK: deterioro aplicado correctamente.\n");
    }

    private static void probarEliminacionDespuesDeCarga(GrafoDirigidoListaAdyacencia grafo) {

        System.out.println("6) Probando eliminacion de neurona despues de cargar CSV...");

        validar(grafo.getContadorNeuronas() == 6,
                "Antes de eliminar debe haber 6 neuronas.");

        validar(grafo.getContadorSinapsis() == 7,
                "Antes de eliminar debe haber 7 sinapsis.");

        boolean eliminada = grafo.eliminarNeurona("4");

        validar(eliminada, "La neurona 4 debe eliminarse correctamente.");

        validar(!grafo.existeNeurona("4"),
                "Despues de eliminar, no debe existir la neurona 4.");

        validar(grafo.getContadorNeuronas() == 5,
                "Despues de eliminar 4, deben quedar 5 neuronas.");

        /*
         * Al eliminar 4 deben desaparecer:
         * 2 -> 4
         * 3 -> 4
         * 4 -> 5
         *
         * De 7 sinapsis deben quedar 4.
         */
        validar(grafo.getContadorSinapsis() == 4,
                "Despues de eliminar 4, deben quedar 4 sinapsis.");

        validar(!grafo.existeSinapsis("2", "4"),
                "No debe existir 2 -> 4 despues de eliminar 4.");

        validar(!grafo.existeSinapsis("3", "4"),
                "No debe existir 3 -> 4 despues de eliminar 4.");

        validar(!grafo.existeSinapsis("4", "5"),
                "No debe existir 4 -> 5 despues de eliminar 4.");

        AnalizadorConectividad analizador = new AnalizadorConectividad();

        ResultadoConectividad bfsDesde1 = analizador.analizarBFS(grafo, "1");

        validar(bfsDesde1.getAlcanzables().tamano() == 4,
                "Despues de eliminar 4, desde 1 deben alcanzarse 4 neuronas.");

        validar(bfsDesde1.getInalcanzables().tamano() == 1,
                "Despues de eliminar 4, desde 1 debe quedar 1 neurona inalcanzable.");

        System.out.println("   Resultado BFS desde 1 despues de eliminar 4:");
        imprimirResultadoConectividad(bfsDesde1);

        System.out.println("   OK: eliminacion posterior a carga CSV correcta.\n");
    }

    private static File crearArchivoNeurotransmisores() throws IOException {

        String contenido =
                "id,nombre,efecto,velocidad,descripcion\n" +
                "GLU,Glutamato,Excitatorio,2.5,\"Principal mediador de informacion sensorial y motora.\"\n" +
                "GABA,Acido Gamma-aminobutirico,Inhibitorio,1.2,\"Reduce la actividad neuronal, control del estres.\"\n" +
                "ACH,Acetilcolina,Excitatorio,2.0,\"Fundamental para la memoria y activacion muscular.\"\n" +
                "DA,Dopamina,Modulador,1.5,\"Regula el placer, recompensa y motivacion.\"\n";

        return crearArchivoTemporal("neurotransmisores_prueba", ".csv", contenido);
    }

    private static File crearArchivoRed() throws IOException {

        String contenido =
                "origen,destino,distancia,ID_Neurotransmisor,coheficiente_eficiencia_sinaptica\n" +
                "1,2,0.85,GLU,1\n" +
                "1,3,0.42,DA,1\n" +
                "2,4,0.91,GLU,1\n" +
                "3,4,0.15,GABA,1\n" +
                "4,5,0.77,GLU,1\n" +
                "5,6,0.33,DA,1\n" +
                "2,6,0.55,ACH,1\n" +

                // Esta linea es duplicada. Debe ignorarse.
                "1,2,0.85,GLU,1\n" +

                // Estas lineas son invalidas. Deben ignorarse.
                "X,Y,-5,GLU,1\n" +
                "7,8,0.20,GLU,1.5\n";

        return crearArchivoTemporal("red_prueba", ".csv", contenido);
    }

    private static File crearArchivoTemporal(String nombre, String extension, String contenido) throws IOException {

        File archivo = File.createTempFile(nombre, extension);
        archivo.deleteOnExit();

        FileWriter writer = new FileWriter(archivo);
        writer.write(contenido);
        writer.close();

        return archivo;
    }

    private static Sinapsis buscarSinapsis(GrafoDirigidoListaAdyacencia grafo, String origen, String destino) {

        ListaEnlazada<Sinapsis> adyacentes = grafo.obtenerAdyacentes(origen);

        if (adyacentes == null || adyacentes.estaVacia()) {
            return null;
        }

        for (int i = 0; i < adyacentes.tamano(); i++) {
            Sinapsis s = adyacentes.obtener(i);

            if (s != null && s.getDestino() != null && destino.equals(s.getDestino().getID())) {
                return s;
            }
        }

        return null;
    }

    private static void imprimirResultadoConectividad(ResultadoConectividad resultado) {

        System.out.println("      Algoritmo: " + resultado.getAlgoritmo());
        System.out.println("      Fuente: " + resultado.getIdFuente());
        System.out.println("      Fuertemente conexa: " + resultado.esFuertementeConexa());

        System.out.print("      Alcanzables: ");
        imprimirLista(resultado.getAlcanzables());

        System.out.print("      Inalcanzables: ");
        imprimirLista(resultado.getInalcanzables());

        System.out.println();
    }

    private static void imprimirLista(ListaEnlazada<String> lista) {

        if (lista == null || lista.estaVacia()) {
            System.out.println("ninguno");
            return;
        }

        for (int i = 0; i < lista.tamano(); i++) {
            System.out.print(lista.obtener(i));

            if (i < lista.tamano() - 1) {
                System.out.print(", ");
            }
        }

        System.out.println();
    }

    private static void validar(boolean condicion, String mensajeError) {

        if (!condicion) {
            throw new RuntimeException("PRUEBA FALLIDA: " + mensajeError);
        }
    }

    private static void validarCasiIgual(double actual, double esperado, String mensajeError) {

        double tolerancia = 0.000001;

        if (Math.abs(actual - esperado) > tolerancia) {
            throw new RuntimeException(
                    "PRUEBA FALLIDA: " + mensajeError +
                    " Esperado: " + esperado +
                    " Actual: " + actual
            );
        }
    }
}