package synapselogic;


public class SynapseLogic {

    public static void main(String[] args) {

    }
}