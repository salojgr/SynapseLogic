/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package synapselogic;

/**
 *
 * @author Salomon Gonzalez
 * 
 * Representa el resultado producido por el algoritmo de Dijkstra.
 * Guarda la secuencia de neuronas recorridas, el costo total y un mensaje
 * comprensible para la interfaz.
 */
public class Ruta {

    private final boolean existeRuta;
    private final ListaEnlazada<String> secuenciaNeuronas;
    private final double costoTotal;
    private final String mensaje;

    public Ruta(boolean existeRuta, ListaEnlazada<String> secuenciaNeuronas, double costoTotal, String mensaje) {
        this.existeRuta = existeRuta;
        this.secuenciaNeuronas = secuenciaNeuronas;
        this.costoTotal = costoTotal;
        this.mensaje = mensaje;
    }

    public static Ruta sinRuta(String mensaje) {
        return new Ruta(false, new ListaEnlazada<>(), Double.POSITIVE_INFINITY, mensaje);
    }

    public static Ruta conRuta(ListaEnlazada<String> secuenciaNeuronas, double costoTotal) {
        return new Ruta(true, secuenciaNeuronas, costoTotal, "Ruta encontrada correctamente.");
    }

    public boolean existeRuta() {
        return existeRuta;
    }

    public ListaEnlazada<String> getSecuenciaNeuronas() {
        return secuenciaNeuronas;
    }

    public double getCostoTotal() {
        return costoTotal;
    }

    public String getMensaje() {
        return mensaje;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append(mensaje).append("\n");

        if (!existeRuta) {
            return sb.toString();
        }

        sb.append("Ruta: ");

        for (int i = 0; i < secuenciaNeuronas.tamano(); i++) {
            sb.append(secuenciaNeuronas.obtener(i));

            if (i < secuenciaNeuronas.tamano() - 1) {
                sb.append(" -> ");
            }
        }

        sb.append("\nCosto total: ").append(costoTotal);

        return sb.toString();
    }
}
