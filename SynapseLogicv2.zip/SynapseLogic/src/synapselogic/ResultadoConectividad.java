/**
 *
 * @author Daniel Vera
 */
package synapselogic;
public class ResultadoConectividad {
   
    private String idFuente;
    private String algoritmo;
    private ListaEnlazada<String> alcanzables;
    private ListaEnlazada<String> inalcanzables;
    private boolean fuertementeConexa;
    
    public ResultadoConectividad(String idFuente, String algoritmo, ListaEnlazada<String> alcanzables, ListaEnlazada<String> inalcanzables, boolean fuertementeConexa ){
    
      this.idFuente = idFuente;
      this.algoritmo = algoritmo;
      this.alcanzables = alcanzables;
      this.inalcanzables = inalcanzables;
      this.fuertementeConexa = fuertementeConexa;
      
    }
    
    public void agregarAlcanzable(String id){
      this.alcanzables.insertarFinal(id);
    }
      
    public void agregarInalcanzable(String id){
      this.inalcanzables.insertarFinal(id);
    }
    
    public ListaEnlazada<String> getAlcanzables(){
        return alcanzables;
    }
      
    public ListaEnlazada<String> getInalcanzables(){
        return inalcanzables;
    }
      
    public boolean esFuertementeConexa() {
        return fuertementeConexa;
    }
    
    public void setFuertementeConexa(boolean fuertementeConexa) {
        this.fuertementeConexa = fuertementeConexa;
    }
    public String getIdFuente(){
        return idFuente;
    }
    public String getAlgoritmo(){
        return algoritmo;
    }
    public int cantidadAlcanzables() {
        return alcanzables.tamano();
    }

    public int cantidadInalcanzables() {
        return inalcanzables.tamano();
    }
}
