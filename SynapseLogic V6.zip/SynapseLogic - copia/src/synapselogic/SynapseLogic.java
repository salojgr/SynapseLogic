package synapselogic;



import javax.swing.UIManager;
import javax.swing.SwingUtilities;

/**
 * Clase principal de ejecución para SynapseLogic.
 * @author Salomón González, Luis Velásquez
 */
public class SynapseLogic {

    /**
     * Método de entrada al sistema.
     * @param args 
     */
    public static void main(String[] args) {
        
        // Configurar un Look and Feel moderno
        
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            
        }

        // Ejecutar en el Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            try {
                // Inicializar el cerebro lógico del Backend (Controlador)
                SynapseLogicController controlador = new SynapseLogicController();
                
                // Inicializar la interfaz pasando el controlador como dependencia
                MainFrame ventanaPrincipal = new MainFrame(controlador);
                
                // Centrar la ventana automáticamente en la pantalla del usuario
                ventanaPrincipal.setLocationRelativeTo(null);
                
                // Desplegar el Dashboard
                ventanaPrincipal.setVisible(true);
                
            } catch (Exception e) {
               
            }
        });
    }
}