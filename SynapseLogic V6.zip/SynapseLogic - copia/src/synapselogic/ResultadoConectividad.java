/**
 *
 * @author Daniel Vera
 */
package synapselogic;

public class ResultadoConectividad {
   
    private String idFuente;
    private String algoritmo;
    private ListaEnlazada<String> alcanzables;
    private ListaEnlazada<String> inalcanzables;
    private boolean fuertementeConexa;
    private ListaEnlazada<String> secuenciaVisita = new ListaEnlazada<>();
    
    public ResultadoConectividad(String idFuente, String algoritmo, ListaEnlazada<String> alcanzables, ListaEnlazada<String> inalcanzables, boolean fuertementeConexa ){
    
      this.idFuente = idFuente;
      this.algoritmo = algoritmo;
      this.alcanzables = alcanzables;
      this.inalcanzables = inalcanzables;
      this.fuertementeConexa = fuertementeConexa;
      
    }
    
    public void agregarAlcanzable(String id){
      this.alcanzables.insertarFinal(id);
    }
      
    public void agregarInalcanzable(String id){
      this.inalcanzables.insertarFinal(id);
    }
    
    public ListaEnlazada<String> getAlcanzables(){
        return alcanzables;
    }
      
    public ListaEnlazada<String> getInalcanzables(){
        return inalcanzables;
    }
      
    public boolean esFuertementeConexa() {
        return fuertementeConexa;
    }
    
    public void setFuertementeConexa(boolean fuertementeConexa) {
        this.fuertementeConexa = fuertementeConexa;
    }
    public String getIdFuente(){
        return idFuente;
    }
    public String getAlgoritmo(){
        return algoritmo;
    }
    public int cantidadAlcanzables() {
        return alcanzables.tamano();
    }

    public int cantidadInalcanzables() {
        return inalcanzables.tamano();
    }
    
    /**
     * Método GETTER: Permite a la interfaz gráfica (PanelResultados) leer 
     * el orden cronológico en el que se exploraron las neuronas.
     * @return List de Strings con los IDs de las neuronas en orden de visita.
     */
    public ListaEnlazada<String> getSecuenciaVisita() {
        return this.secuenciaVisita;
    }

    /**
     * Método SETTER: Permite al motor analítico (Grafo/Controlador) inyectar
     * la lista con el recorrido final una vez concluido el algoritmo.
     * @param secuenciaVisita Lista con la traza de exploración calculada.
     */
    public void setSecuenciaVisita(ListaEnlazada<String> secuenciaVisita) {
        // Programación defensiva: Si pasan un nulo, inicializa una lista vacía para evitar fallos
        if (secuenciaVisita == null) {
            this.secuenciaVisita = new ListaEnlazada<>();
        } else {
            this.secuenciaVisita = secuenciaVisita;
        }
    }
}
    
    

