/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package synapselogic;
/**
 *
 * @author Luis Velásquez
 */


import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Component;
import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.Edge;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.view.Viewer;
import org.graphstream.ui.swing_viewer.SwingViewer;
import org.graphstream.ui.view.View;

/**
 * Clase Frontera encargada de renderizar la red neuronal de forma gráfica e interactiva.
 * Integra la librería GraphStream dentro de un contenedor JPanel de Swing.
 */
@SuppressWarnings("serial")
public class VisualizadorGrafoGraphStream extends JPanel {

    private final Graph grafoGS;
    private Viewer visor;
    private View vista;

    // Estilos visuales en formato CSS nativo de GraphStream
    private final String hojaEstilos = 
        "node {" +
        "   size: 26px;" +
        "   fill-color: #2c3e50;" +
        "   text-mode: normal;" +
        "   text-color: #2c3e50;" +
        "   text-size: 13px;" +
        "   text-style: bold;" +
        "   text-alignment: at-right;" + 
        "   stroke-mode: plain;" +
        "   stroke-color: #34495e;" +
        "   stroke-width: 2px;" +
        "}" +
        "edge {" +
        "   fill-color: #bdc3c7;" +
        "   size: 2px;" +
        "   arrow-size: 8px, 4px;" +
        "}";

    public VisualizadorGrafoGraphStream() {
        // Indicar a GraphStream que renderice utilizando la extensión de Swing
        System.setProperty("org.graphstream.ui", "swing");
        
        // Configurar el panel con BorderLayout
        this.setLayout(new BorderLayout());
        
        // Inicializar el contenedor del grafo visual
        this.grafoGS = new SingleGraph("RedNeuronalVisual");
        this.grafoGS.setAttribute("ui.stylesheet", hojaEstilos);
        this.grafoGS.setAttribute("ui.antialias"); // Suavizado de líneas
        
        inicializarVisor();
    }

    /**
     * Configura el visor interno y empotra el lienzo interactivo dentro de este JPanel.
     */
    private void inicializarVisor() {
        this.visor = new SwingViewer(grafoGS, Viewer.ThreadingModel.GRAPH_IN_ANOTHER_THREAD);
        this.visor.enableAutoLayout(); // Los nodos se repelen de forma elástica automáticamente
        
        this.vista = visor.addDefaultView(false); // false indica que no es una ventana independiente
        
        // Colocar el visualizador en el centro del panel
        this.add((Component) vista, BorderLayout.CENTER);
    }

    /**
     * Limpiar la interfaz visual y proyectar las estructuras de 
     * la clase GrafoDirigidoListaAdyacencia a elementos gráficos de GraphStream.
     * @param grafoBackend Instancia con los datos cargados desde el controlador.
     * 
     */
    public void actualizarGrafo(GrafoDirigidoListaAdyacencia grafoBackend) {
        if (grafoBackend == null) return;

        // Limpiar el lienzo para evitar duplicaciones o colisiones de IDs al recargar
        grafoGS.clear();
        grafoGS.setAttribute("ui.stylesheet", hojaEstilos);
        grafoGS.setAttribute("ui.antialias");

        // Recorrer la lista de identificadores del backend
        ListaEnlazada<String> ids = grafoBackend.getListaIds();
        
        // Mapear y registrar todas las Neuronas (Nodos)
        for (int i = 0; i < ids.tamano(); i++) {
            String idNeurona = ids.obtener(i);
            if (idNeurona != null) {
                Node nodeGS = grafoGS.addNode(idNeurona);
                nodeGS.setAttribute("ui.label", idNeurona);
            }
        }

        // Mapear y registrar todas las Sinapsis (Bordes dirigidos)
        for (int i = 0; i < ids.tamano(); i++) {
            String idOrigen = ids.obtener(i);
            ListaEnlazada<Sinapsis> sinapsisLista = grafoBackend.obtenerSinapsisDe(idOrigen);
            
            if (sinapsisLista != null) {
                for (int j = 0; j < sinapsisLista.tamano(); j++) {
                    Sinapsis sinapsisActual = sinapsisLista.obtener(j);
                    if (sinapsisActual != null) {
                        String idDestino = sinapsisActual.getDestino().getID();
                        String idBorde = idOrigen + "-" + idDestino;
                        
                        // Evitar registrar aristas duplicadas en el visualizador
                        if (grafoGS.getEdge(idBorde) == null) {
                            grafoGS.addEdge(idBorde, idOrigen, idDestino, true); // true = Dirigido
                        }
                    }
                }
            }
        }
        
        //Aplicar actualizaciones al visualizador.
        this.revalidate();
        this.repaint();
    }

    /**
     * Resaltar visualmente un camino específico (secuencia de IDs de una Ruta de Dijkstra)
     * pintando las aristas involucradas de un color llamativo para el usuario.
     * @param secuenciaIds Lista enlazada con la secuencia de IDs de la ruta óptima.
     * 
     */
    
    public void resaltarRuta(ListaEnlazada<String> secuenciaIds) {
        if (secuenciaIds == null || secuenciaIds.tamano() < 2) return;
        
        grafoGS.edges().forEach(e -> {
            e.setAttribute("ui.style", "fill-color: #bdc3c7; size: 2px;");
        });

        // Pintar la secuencia de la nueva ruta calculada
        for (int i = 0; i < secuenciaIds.tamano() - 1; i++) {
            String origen = secuenciaIds.obtener(i);
            String destino = secuenciaIds.obtener(i + 1);
            String idBorde = origen + "-" + destino;
            
            Edge e = grafoGS.getEdge(idBorde);
            if (e != null) {
                // Hacer que la arista sea más gruesa y cambie su color a naranja
                e.setAttribute("ui.style", "fill-color: #e67e22; size: 5px;");
            }
        }
    }
}