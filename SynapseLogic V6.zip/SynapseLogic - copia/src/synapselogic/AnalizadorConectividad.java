package synapselogic;

/**
 * @author Salomon Gonzalez
 * Clase encargada de analizar la conectividad de la red sináptica.
 * Implementa recorridos BFS y DFS sobre un grafo dirigido para detectar
 * neuronas alcanzables e inalcanzables desde una fuente.
 */

public class AnalizadorConectividad {
    
    private void validarEntrada(GrafoDirigidoListaAdyacencia grafo, String idFuente) {

        if (grafo == null) {
            throw new IllegalArgumentException("El grafo no puede ser nulo.");
        }

        if (idFuente == null || idFuente.trim().isEmpty()) {
            throw new IllegalArgumentException("La neurona fuente no puede estar vacía.");
        }

        if (!grafo.existeNeurona(idFuente)) {
            throw new IllegalArgumentException("La neurona fuente no existe en el grafo.");
        }
    }
       private TablaHash<String, Boolean> recorridoBFS(GrafoDirigidoListaAdyacencia grafo, String idFuente) {

        TablaHash<String, Boolean> visitados = new TablaHash<>();
        Cola<String> cola = new Cola<>();

        visitados.insertar(idFuente, true);
        cola.encolar(idFuente);

        while (!cola.estaVacia()) {

            String actual = cola.desencolar();

            ListaEnlazada<Sinapsis> adyacentes = grafo.obtenerAdyacentes(actual);

            if (adyacentes != null && !adyacentes.estaVacia()) {

                for (int i = 0; i < adyacentes.tamano(); i++) {

                    Sinapsis sinapsis = adyacentes.obtener(i);

                    if (sinapsis != null && sinapsis.getDestino() != null) {

                        String idDestino = sinapsis.getDestino().getID();

                        if (!visitados.contieneClave(idDestino)) {
                            visitados.insertar(idDestino, true);
                            cola.encolar(idDestino);
                        }
                    }
                }
            }
        }

        return visitados;
    }
     
    private TablaHash<String, Boolean> recorridoDFS(GrafoDirigidoListaAdyacencia grafo, String idFuente) {

        TablaHash<String, Boolean> visitados = new TablaHash<>();
        Pila<String> pila = new Pila<>();

        pila.apilar(idFuente);

        while (!pila.estaVacia()) {

            String actual = pila.desapilar();

            if (!visitados.contieneClave(actual)) {

                visitados.insertar(actual, true);

                ListaEnlazada<Sinapsis> adyacentes = grafo.obtenerAdyacentes(actual);

                if (adyacentes != null && !adyacentes.estaVacia()) {

                    for (int i = 0; i < adyacentes.tamano(); i++) {

                        Sinapsis sinapsis = adyacentes.obtener(i);

                        if (sinapsis != null && sinapsis.getDestino() != null) {

                            String idDestino = sinapsis.getDestino().getID();

                            if (!visitados.contieneClave(idDestino)) {
                                pila.apilar(idDestino);
                            }
                        }
                    }
                }
            }
        }

        return visitados;
    }
    
        private ResultadoConectividad construirResultado(
            GrafoDirigidoListaAdyacencia grafo,
            String idFuente,
            String algoritmo,
            TablaHash<String, Boolean> visitados) {

        ListaEnlazada<String> alcanzables = new ListaEnlazada<>();
        ListaEnlazada<String> inalcanzables = new ListaEnlazada<>();

        ListaEnlazada<String> ids = grafo.getListaIds();

        for (int i = 0; i < ids.tamano(); i++) {

            String idActual = ids.obtener(i);

            if (visitados.contieneClave(idActual)) {
                alcanzables.insertarFinal(idActual);
            } else {
                inalcanzables.insertarFinal(idActual);
            }
        }

        boolean fuertementeConexa = esFuertementeConexa(grafo);

        ResultadoConectividad resultado =  new ResultadoConectividad(idFuente,algoritmo,alcanzables,inalcanzables,fuertementeConexa);
        return resultado;
    }

    public boolean esFuertementeConexa(GrafoDirigidoListaAdyacencia grafo) {

        if (grafo == null || grafo.getContadorNeuronas() == 0) {
            return false;
        }

        ListaEnlazada<String> ids = grafo.getListaIds();

        for (int i = 0; i < ids.tamano(); i++) {

            String idFuente = ids.obtener(i);

            TablaHash<String, Boolean> visitados = recorridoBFS(grafo, idFuente);

            for (int j = 0; j < ids.tamano(); j++) {

                String idDestino = ids.obtener(j);

                if (!visitados.contieneClave(idDestino)) {
                    return false;
                }
            }
        }

        return true;
    }
    public ResultadoConectividad analizarBFS(GrafoDirigidoListaAdyacencia grafo, String idFuente) {
        validarEntrada(grafo, idFuente);

        TablaHash<String, Boolean> visitados = recorridoBFS(grafo, idFuente);

        return construirResultado(grafo, idFuente, "BFS", visitados);
    }

    public ResultadoConectividad analizarDFS(GrafoDirigidoListaAdyacencia grafo, String idFuente) {
        validarEntrada(grafo, idFuente);

        TablaHash<String, Boolean> visitados = recorridoDFS(grafo, idFuente);

        return construirResultado(grafo, idFuente, "DFS", visitados);
    }



 




}
