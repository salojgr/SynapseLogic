/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package synapselogic;
import java.io.File;
/**
 *
 * @author Salomon Gonzalez
 * 
 * Controlador principal de la aplicación SynapseLogic.
 *
 * Esta clase coordina la comunicación entre la interfaz gráfica y el núcleo lógico
 * del sistema. Mantiene en memoria el grafo actual, el diccionario de
 * neurotransmisores y el estado de la sesión.
 *
 */
public class SynapseLogicController {

    private GrafoDirigidoListaAdyacencia grafo;
    private TablaHash<String, Neurotransmisor> diccionario;
    private final EstadoRed estado;

    /**
     * Crea un controlador sin red ni diccionario cargados.
     */
    public SynapseLogicController() {
        this.grafo = null;
        this.diccionario = null;
        this.estado = new EstadoRed();
    }

    /**
     * Carga una red sináptica desde un archivo CSV.
     *
     * @param archivo archivo CSV seleccionado por el usuario.
     * @return mensaje descriptivo del resultado de la carga.
     * @throws IllegalArgumentException si el archivo es nulo, no existe o no es válido.
     */
    public String cargarRed(File archivo) {
        validarArchivo(archivo, "red sináptica");

        CargadorRedCSV cargador = new CargadorRedCSV();
        GrafoDirigidoListaAdyacencia grafoCargado = cargador.cargar(archivo.getAbsolutePath());

        if (grafoCargado == null) {
            this.estado.setRedCargada(false);
            throw new IllegalStateException("No se pudo cargar la red sináptica.");
        }

        this.grafo = grafoCargado;
        this.estado.setRedCargada(true);
        this.estado.setCambiosSinGuardar(false);

        return "Red sináptica cargada correctamente.\n"
                + "Archivo: " + archivo.getName() + "\n"
                + "Neuronas: " + grafo.getContadorNeuronas() + "\n"
                + "Sinapsis: " + grafo.getContadorSinapsis();
    }

    /**
     * Carga un diccionario de neurotransmisores desde un archivo CSV.
     *
     * @param archivo archivo CSV seleccionado por el usuario.
     * @return mensaje descriptivo del resultado de la carga.
     * @throws IllegalArgumentException si el archivo es nulo, no existe o no es válido.
     */
    public String cargarDiccionario(File archivo) {
        validarArchivo(archivo, "diccionario de neurotransmisores");

        CargadorNeurotransmisoresCSV cargador = new CargadorNeurotransmisoresCSV();
        TablaHash<String, Neurotransmisor> diccionarioCargado = cargador.cargar(archivo.getAbsolutePath());

        if (diccionarioCargado == null || diccionarioCargado.estaVacia()) {
            this.estado.setDiccionarioCargado(false);
            throw new IllegalStateException("No se pudo cargar el diccionario de neurotransmisores.");
        }

        this.diccionario = diccionarioCargado;
        this.estado.setDiccionarioCargado(true);

        return "Diccionario de neurotransmisores cargado correctamente.\n"
                + "Archivo: " + archivo.getName() + "\n"
                + "Neurotransmisores: " + diccionario.tamano();
    }

    /**
     * Ejecuta un análisis de conectividad usando BFS desde una neurona fuente.
     *
     * @param idFuente ID de la neurona fuente.
     * @return resultado del análisis de conectividad.
     */
    public ResultadoConectividad analizarBFS(String idFuente) {
        validarRedCargada();

        String fuente = normalizarId(idFuente, "fuente");

        AnalizadorConectividad analizador = new AnalizadorConectividad();
        return analizador.analizarBFS(grafo, fuente);
    }

    /**
     * Ejecuta un análisis de conectividad usando DFS desde una neurona fuente.
     *
     * @param idFuente ID de la neurona fuente.
     * @return resultado del análisis de conectividad.
     */
    public ResultadoConectividad analizarDFS(String idFuente) {
        validarRedCargada();

        String fuente = normalizarId(idFuente, "fuente");

        AnalizadorConectividad analizador = new AnalizadorConectividad();
        return analizador.analizarDFS(grafo, fuente);
    }

    /**
     * Calcula la ruta de menor tiempo de transmisión entre dos neuronas usando
     * Dijkstra.
     *
     * @param origen ID de la neurona origen.
     * @param destino ID de la neurona destino.
     * @return objeto Ruta con la secuencia, costo total y mensaje asociado.
     */
    public Ruta calcularRuta(String origen, String destino) {
        validarRedCargada();
        validarDiccionarioCargado();

        String idOrigen = normalizarId(origen, "origen");
        String idDestino = normalizarId(destino, "destino");

        CalculadorRutaDijkstra calculador = new CalculadorRutaDijkstra();
        return calculador.calcularRuta(grafo, diccionario, idOrigen, idDestino);
    }

    /**
     * Aplica un ciclo de deterioro cognitivo sobre todas las sinapsis de la red.
     *
     * @return mensaje descriptivo de la operación.
     */
    public String simularDeterioro() {
        validarRedCargada();

        SimuladorDeterioro simulador = new SimuladorDeterioro(grafo);
        simulador.ejecutarCicloFatiga();

        estado.setCambiosSinGuardar(true);

        return "Deterioro aplicado correctamente.\n"
                + "Los coeficientes k de las sinapsis fueron actualizados.";
    }

    /**
     * Elimina una neurona y sus conexiones entrantes y salientes.
     *
     * @param id ID de la neurona a eliminar.
     * @return mensaje descriptivo de la operación.
     */
    public String eliminarNeurona(String id) {
        validarRedCargada();

        String idNeurona = normalizarId(id, "neurona");

        boolean eliminada = grafo.eliminarNeurona(idNeurona);

        if (!eliminada) {
            return "No se pudo eliminar la neurona '" + idNeurona + "'. Verifique que exista.";
        }

        estado.setCambiosSinGuardar(true);

        return "Neurona '" + idNeurona + "' eliminada correctamente.\n"
                + "Neuronas restantes: " + grafo.getContadorNeuronas() + "\n"
                + "Sinapsis restantes: " + grafo.getContadorSinapsis();
    }

    /**
     * Agrega una neurona aislada al grafo actual.
     *
     * @param id ID de la nueva neurona.
     * @return mensaje descriptivo de la operación.
     */
    public String agregarNeurona(String id) {
        validarRedCargada();

        String idNeurona = normalizarId(id, "neurona");

        if (grafo.existeNeurona(idNeurona)) {
            return "La neurona '" + idNeurona + "' ya existe.";
        }

        grafo.agregarNeurona(new Neurona(idNeurona));
        estado.setCambiosSinGuardar(true);

        return "Neurona '" + idNeurona + "' agregada correctamente.\n"
                + "Neuronas totales: " + grafo.getContadorNeuronas();
    }

    /**
     * Agrega una sinapsis dirigida al grafo actual.
     *
     * Si las neuronas origen o destino no existen, se delega en el grafo la
     * creación automática de dichas neuronas, siempre que esa lógica esté
     * implementada en GrafoDirigidoListaAdyacencia.
     *
     * @param origen ID de la neurona origen.
     * @param destino ID de la neurona destino.
     * @param distancia distancia sináptica.
     * @param idNeurotransmisor ID del neurotransmisor asociado.
     * @param k coeficiente de eficiencia sináptica.
     * @return mensaje descriptivo de la operación.
     */
    public String agregarSinapsis(String origen, String destino, double distancia, String idNeurotransmisor, double k) {
        validarRedCargada();

        String idOrigen = normalizarId(origen, "origen");
        String idDestino = normalizarId(destino, "destino");
        String nt = normalizarId(idNeurotransmisor, "neurotransmisor");

        if (distancia <= 0) {
            throw new IllegalArgumentException("La distancia debe ser mayor que 0.");
        }

        if (k <= 0 || k > 1) {
            throw new IllegalArgumentException("El coeficiente k debe estar entre > 0 y 1.");
        }

        if (grafo.existeSinapsis(idOrigen, idDestino)) {
            return "La sinapsis '" + idOrigen + "' -> '" + idDestino + "' ya existe.";
        }

        grafo.agregarSinapsis(idOrigen, idDestino, distancia, nt, k);

        if (!grafo.existeSinapsis(idOrigen, idDestino)) {
            throw new IllegalStateException("No se pudo agregar la sinapsis.");
        }

        estado.setCambiosSinGuardar(true);

        return "Sinapsis agregada correctamente:\n"
                + idOrigen + " -> " + idDestino + "\n"
                + "Neurotransmisor: " + nt + "\n"
                + "Distancia: " + distancia + "\n"
                + "k: " + k;
    }

    /**
     * Devuelve un resumen textual de la red cargada.
     *
     * @return resumen de neuronas, sinapsis y estado.
     */
    public String resumenRed() {
        validarRedCargada();

        return "Resumen de la red actual:\n"
                + "Neuronas: " + grafo.getContadorNeuronas() + "\n"
                + "Sinapsis: " + grafo.getContadorSinapsis() + "\n"
                + "Diccionario cargado: " + estado.estaDiccionarioCargado() + "\n"
                + "Cambios sin guardar: " + estado.CambiosSinGuardar();
    }

    /**
     * Marca los cambios actuales como guardados.
     * Este método será útil cuando se implemente GuardadorCSV.
     */
    public void marcarComoGuardado() {
        estado.setCambiosSinGuardar(false);
    }

    /**
     * Indica si debería pedirse confirmación antes de reemplazar la red actual.
     *
     * @return true si hay red cargada y cambios sin guardar.
     */
    public boolean requiereConfirmacionParaNuevaRed() {
        return estado.estaRedCargada() && estado.CambiosSinGuardar();
    }

    /**
     * Devuelve el estado operativo de la sesión.
     *
     * @return estado actual.
     */
    public EstadoRed getEstado() {
        return estado;
    }

    /**
     * Devuelve el grafo actualmente cargado.
     *
     * @return grafo actual.
     */
    public GrafoDirigidoListaAdyacencia getGrafo() {
        return grafo;
    }

    /**
     * Devuelve el diccionario de neurotransmisores actualmente cargado.
     *
     * @return tabla hash de neurotransmisores.
     */
    public TablaHash<String, Neurotransmisor> getDiccionario() {
        return diccionario;
    }

    /**
     * Valida que exista una red cargada antes de ejecutar operaciones sobre el grafo.
     */
    private void validarRedCargada() {
        if (grafo == null || !estado.estaRedCargada()) {
            throw new IllegalStateException("Debe cargar una red sináptica primero.");
        }
    }

    /**
     * Valida que exista un diccionario cargado antes de calcular rutas ponderadas.
     */
    private void validarDiccionarioCargado() {
        if (diccionario == null || diccionario.estaVacia() || !estado.estaDiccionarioCargado()) {
            throw new IllegalStateException("Debe cargar el diccionario de neurotransmisores primero.");
        }
    }

    /**
     * Valida que un archivo sea utilizable.
     *
     * @param archivo archivo recibido.
     * @param tipoArchivo descripción del tipo de archivo.
     */
    private void validarArchivo(File archivo, String tipoArchivo) {
        if (archivo == null) {
            throw new IllegalArgumentException("No se seleccionó ningún archivo de " + tipoArchivo + ".");
        }

        if (!archivo.exists()) {
            throw new IllegalArgumentException("El archivo de " + tipoArchivo + " no existe.");
        }

        if (!archivo.isFile()) {
            throw new IllegalArgumentException("La ruta seleccionada no corresponde a un archivo válido.");
        }
    }

    /**
     * Limpia y valida un ID recibido desde la interfaz o desde otro servicio.
     *
     * @param id valor recibido.
     * @param nombreCampo nombre del campo para mensajes de error.
     * @return ID limpio.
     */
    private String normalizarId(String id, String nombreCampo) {
        if (id == null) {
            throw new IllegalArgumentException("El ID de " + nombreCampo + " no puede ser nulo.");
        }

        String limpio = id.trim();

        if (limpio.isEmpty()) {
            throw new IllegalArgumentException("El ID de " + nombreCampo + " no puede estar vacío.");
        }

        return limpio;
    }
}

